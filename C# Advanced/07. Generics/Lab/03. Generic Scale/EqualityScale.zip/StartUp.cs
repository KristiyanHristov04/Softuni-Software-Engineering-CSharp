﻿using System;

namespace GenericScale
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            //var areEqual = EqualityScale<int>.Equals(15, 15);
            //Console.WriteLine(areEqual);
        }
    }
}
