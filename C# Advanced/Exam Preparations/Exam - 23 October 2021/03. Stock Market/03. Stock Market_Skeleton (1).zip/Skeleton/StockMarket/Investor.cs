﻿namespace StockMarket
{
    public class Investor
    {
     
    }
}
