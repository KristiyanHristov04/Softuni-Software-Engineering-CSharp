﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public abstract class AbstractClass
    {
        public string Id { get; set; }
    }
}
