﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public abstract class AbstractClass
    {
        public string Id { get; set; }
    }
}
