﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MillitaryElite.Core
{
    public interface IEngine
    {
        public void Run();
    }
}
